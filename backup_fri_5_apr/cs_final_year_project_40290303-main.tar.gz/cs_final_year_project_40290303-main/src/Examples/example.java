package Examples;

import uk.ac.ic.doc.jpair.api.Pairing;
import uk.ac.ic.doc.jpair.pairing.BigInt;
import uk.ac.ic.doc.jpair.pairing.EllipticCurve;
import uk.ac.ic.doc.jpair.pairing.Point;
import uk.ac.ic.doc.jpair.pairing.Predefined;

import java.util.Random;
//...
//using a predefined pairing

class example{
public static void main(String args[])
{

// this is the starting point
Pairing e = Predefined.nssTate();

//get P, which is a random point in group G1
Point P = e.RandomPointInG1(new Random());

    System.out.println("\nP = "+ P);


//get Q, which is a random point in group G2
//Point Q = e.RandomPointInG2(new Random());


//////////////////////////////////////////
// this is not needed for our computation
//compute e(P,Q)
//FieldElement epq =e.compute(P,Q);
/////////////////////////////////////////


//
//the curve on which G1 is defined
EllipticCurve g1 = e.getCurve();



// Alice wants to compute g^a where a is known to Alice and secret to the rest of the world
// g = P
// here we take the generator to be P.


// the secret random a
//a is a 160-bit random integer
BigInt a = new BigInt(160,new Random());
    System.out.println("\na = "+ a);


// g^a = aP
//Point aP is computed over G1
Point S = g1.multiply(P, a); 
    System.out.println("\n\n\nS = "+ S);

//Note that if S and P are known, then also it is difficult to know a.


// g^b = bP
//Point aP is computed over G1
BigInt b = new BigInt(160,new Random());
Point T = g1.multiply(P, b); 

//Note that if S and P are known, then also it is difficult to know a.
//Note that if T and P are known, then also it is difficult to know b.
////////////////////////////////////////////////////////////////////////


// Alice will send S to Bob and Bob will send T to Alice

//Alice will compute the following : (g^b)^a = a.T
Point X = g1.multiply(T, a);


//Bob will compute the following : (g^a)^b = b.S
Point Y = g1.multiply(S, b);

if(X.equals(Y))
{
    System.out.println("\n\nthe scheme is working");
    System.out.println("\nX = "+ X);
    System.out.println("\n\n\n\nY = "+ Y);
}
else{
    System.out.println("the scheme is not working");
}

///////////////////////////////////////////////////////////////////////
// this is not needed
//The curve on which G2 is defined
//EllipticCurve g2 = e.getCurve2();

//b is a 160-bit random integer
//BigInt b = new BigInt(160,new Random());
//bQ is computed over G2
//Point bQ = g2.multiply(Q, b); 

//compute e(aP,bQ)
//FieldElement res = e.compute(aP,bQ);
///////////////////////////////////////////////////////////////////

//compute e(P,Q)^ab, this is done in group Gt
//BigInt ab = a.multiply(b);
//get the field on which Gt is defined
//Field gt = e.getGt();
//FieldElement res2 = gt.pow(epq,ab);



//compare these two
/*
if(res.equals(res2)){
    System.out.println("Correct! e(aP,bQ) = e(P,Q)^ab");
}
else{
    System.out.println("Something is wrong! e(aP,BQ) != e(P,Q)^ab");
}*/

}
}
