package Examples;

import uk.ac.ic.doc.jpair.api.Field;
import uk.ac.ic.doc.jpair.api.FieldElement;
import uk.ac.ic.doc.jpair.api.Pairing;
import uk.ac.ic.doc.jpair.pairing.*;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class EncrypExample {

    int RANGE;

//    static boolean flag = false;
 // private static Encryption _encr;
  // public parameters(key)
  static Point _gPoint;
  static Point _g2Point;
  static Point _hPoint;

  // private parameter(key)
  static BigInt _a;

  
  //the curve on which G1 is defined 
  static EllipticCurve _g1;

  static EllipticCurve _g2;

  static String _key;
  static String _IV;
  static BigInt _p;
  static Fp _fp;
  static Pairing _e;

  //datastructures for preprocessing
  static List<BigInt> _iList;
  static HashMap<BigInt,Point> _AList;

  // CTOR !
  // This constructor is used for key generation
  //
  public void GenKey()
  {
       RANGE = 200;

       _e = Predefined.nssTate();
  //     Pairing e = Predefined.nssTate();

       //get P, which is a random point in group G1 
       _gPoint = _e.RandomPointInG1(new Random());
       
       //get Q, which is a random point in group G2
       _g2Point = _e.RandomPointInG2(new Random());
  
       
       //a is a 160-bit random integer
       _a = new BigInt(160,new Random()); 
                
       //the curve on which G1 is defined 
       _g1 = _e.getCurve();
  
       //the curve on which G2 is defined 
       _g2 = _e.getCurve2();
      
       //Point aP is computed over G1
       _hPoint = _g1.multiply(_gPoint,_a );
  
       SecureRandom srand=new SecureRandom();

       _key = (new BigInteger(80, srand)).toString(32);
       _IV =  (new BigInteger(80, srand)).toString(32);

       _p = BigInt.probablePrime(160,new Random()); 
       _fp = new Fp(_p);                               
   
       _e = Predefined.nssTate();
       _iList = new ArrayList<BigInt>();
       _AList = new HashMap<BigInt,Point>();
       _iList.add(new BigInt("0"));
       //
       RANGE = 200;
       for(int i = 1;i<=RANGE;i++)
       {
           BigInt obj = new BigInt(Integer.toString(i));
           //
           _iList.add(obj);
           _AList.put(obj,_g1.multiply(_gPoint,obj));
  //         System.out.println("size of ilist " + _iList.size());
       }
//       System.out.println("size of ilist " + _iList.size());
       //

       WriteKeysInFile();
  }

  public EncrypExample()
  {
      RANGE = 200;
  }

 
  
  public byte[] EncryptBytes
  (
    String IV, 
    byte[] data, 
    String encryptionKey
  ) throws Exception 
  {
  
    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
    SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), "AES");
    cipher.init(Cipher.ENCRYPT_MODE, key,new IvParameterSpec(IV.getBytes("UTF-8")));
    return cipher.doFinal(data);
  }
  
  public static byte[] encrypt
          (
                  String IV,
                  String plainText,
                  String encryptionKey
          ) throws Exception
  {
  
    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
    SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), "AES");
    cipher.init(Cipher.ENCRYPT_MODE, key,new IvParameterSpec(IV.getBytes("UTF-8")));
    return cipher.doFinal(plainText.getBytes("UTF-8"));
  }

  
  
  public String Decrypt
  (
    String IV, 
    byte[] cipherText, 
    String encryptionKey
  ) throws Exception
  {

    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
    SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), "AES");
    cipher.init(Cipher.DECRYPT_MODE, key,new IvParameterSpec(IV.getBytes("UTF-8")));
    return new String(cipher.doFinal(cipherText),"UTF-8");
  }



  

   // This function encrypts files using HE based scheme
   //
   public void EncryptFiles
   (
    int str,
    int num                 // number of files to be encrypted
   )throws IOException
   {
   
        try{
        long stime = System.nanoTime();
        for(int j = str; j<=num;j++)
        {
            List<String> Alist = new ArrayList<String>();
            List<byte[]> Blist = new ArrayList<byte[]>();
            
            BufferedReader fl = new BufferedReader(new FileReader("/home//indranil//Desktop//Docs//TRAIN//"+j+".txt"));

            String line1;
            BigInt I = new BigInt("1");
            int i = 1;
        //    long stime = System.nanoTime();
        ////////////////////////////////////////////////////////////////////////////////////////////////
        //SYMMETRIC ENCRYPTION
        Path path = Paths.get(new String("/home//indranil//Desktop//Docs//TRAIN//"+j+".txt"));
        byte [] flByte = Files.readAllBytes(path);
        byte [] encryptedData =  EncryptBytes(_IV,flByte,_key); 
        ////////////////////////////////////////////////////////////////////////////////////////////////
        //PEKS ENCRYPTION
            while((line1 = fl.readLine()) != null)
            {

                try{
                    
                    String [] arr = line1.split(",");
                    //System.out.println("\n"+arr[0]+": "+i + "   --------------------------------------\n");

                    // E(w) = [A,B]. 
                    // now we compute first component A = ig, where i is position of word w and g is primitive point
                                 
      
                    // A = gi
                    //Point gi = _g1.multiply(_gPoint,I);
                    //String gis = gi.toString();

                    //System.out.println(aP.toString());
                
                    // now we compute the second component B as follows.
                    //B = e(h^i,H1(w)

                    // computation of hi
                    //System.out.println("\n i ==== " + i+"ilist size = "+_iList.size() + "\n");
                    Point hi = _g1.multiply(_hPoint,_iList.get(i));
                
                    // computation of H1(w) :
                    // we compute hmac(w) then convert it to
                    // bigint hw. 
                    // Next we multiply primitive point 
                    // of curve2  with hw to get a point on curve2 say p2.
                    // next we compute e(hi,p2).

                    //hw
                    String ss = HMAC(arr[0].getBytes(),_key);
                    BigInt hw = new BigInt(ss.getBytes());
                    Point pt2 = _g2.multiply(_g2Point,hw);//getPoint(hw);
                    

                   //System.out.println(pt2.toString());

                    // compute res = e(hi,p2)
                    FieldElement res = _e.compute(hi,pt2);

                    // compute B = htw = hmac(res)
                    byte[] htw = HMAC_byte(res.toString().getBytes(),_key);
                    String hss = new String(htw);
                    //if(i >= 38 && i <= 40)
                    //{
                      //  System.out.println("during encryption :  " +  hss);
                    //}
                /////////////////////////////////////////////////////   
                    Alist.add(_AList.get(_iList.get(i)).toString());
                    Blist.add(htw);
                    //System.out.println(htw);
                    //System.out.println(htw.getBytes());
                    //System.out.println(new String (htw.getBytes()));

                }
                catch (Exception excep) {

                                  excep.printStackTrace();

                } 
                //

            //I = I.add(BigInt.ONE);
            i++;

            }

                    //now we write encrypted data in files
                    WriteEncryptedData(Alist,Blist,j,encryptedData);
                    //WriteKeysInFile();
                    //ReadData();
                    //SearchWord("ao");
        }
                long etime = System.nanoTime();
                long dur = etime - stime;
                long sec = TimeUnit.SECONDS.convert(dur,TimeUnit.NANOSECONDS);
                System.out.println("time for encryption (sec) =" + sec);
   }
   catch(Exception ee)
   {

   }

   }

   public void DecryptFiles(List<Integer> fp)
   {

       try{
       for(int i = 0; i< fp.size(); i++)
       {
           int pos = fp.get(i).intValue();
           //
           Path p = Paths.get(new String("/home//indranil//Desktop//Docs//TRAIN_e//ae"+pos+".txt"));
           //
           byte[] cd = Files.readAllBytes(p);
           String msg = Decrypt(_IV, cd, _key);
           //
           PrintWriter out = new PrintWriter(new String("/home//indranil//Desktop//Docs//TRAIN_demotime_decrypt//m"+pos+".txt"));
           out.println(msg);
           out.close();
           
       }
       }
       catch(Exception ee)
       {
       }

   }


   private void SearchWord(String w)
   {
      String [] arr = null;//line.split(",");
      try{
      Point tr = Trapdoor(w);
      //System.out.println("trapdoor : ");//\t "+ tr.toString());
      //
      //System.out.println("searching ..");

      // A = gi
      int i = 1;
     
      //Path p = Paths.get("e1.txt");
      Path p = Paths.get(new String("/home//indranil//Desktop//Docs//TRAIN_e//e231.txt"));
      //BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fr),"UTF-8"));
      byte [] flByte = Files.readAllBytes(p);
      System.out.println("file size = "+flByte.length);
      int blockNumber = flByte.length /20;
      
      while(i < blockNumber )
      {
          //System.out.println("searching ............................................");
          // compute res = e(hi,p2)
          FieldElement res = _e.compute(_AList.get(_iList.get(i)),tr);
                    
          // compute B = htw = hmac(res)
          String htw = HMAC(res.toString().getBytes(),_key);

          //
          int scp = (i-1)*20;
          byte [] line = new byte[20];
          System.arraycopy(flByte,scp,line,0,20);
              String ls = new String(line);
              
              //if(i>=28 && i<=30)
              //{
                System.out.println("\n the line is "+ ls);
                System.out.println("\n the ptrn is "+ htw);
              //}
              if(ls.equals(htw))
              {
                System.out.println("\n hurreyyyyyyyyy this exists at " +i +"th position");
                //System.out.println("\n this is tobe matched :   \n" + htw);
                //br.close();
                break;
              }
          i++;
      }
      //ios.close();
     }
     catch(Exception e)
     {
            e.printStackTrace();
     }
   }


   private void WriteEncryptedData(List<String> Al, List<byte[]> Bl, int pos, byte[] ed)
   {
       try{
           FileOutputStream fio = new FileOutputStream("/home//indranil//Desktop//Docs//TRAIN_e//e"+pos+".txt",true);
           FileOutputStream afio = new FileOutputStream("/home//indranil//Desktop//Docs//TRAIN_e//ae"+pos+".txt",true);
           //

           // write aes encrypted data
           afio.write(ed);
           afio.close();
           
           
           //write PEKS encrypted data

            for(int i = 0; i<Bl.size();i++)
            {
                byte [] b = Bl.get(i);
                //
                fio.write(b);

            }
       //
       fio.close();
       }
       catch(Exception e)
       {
            e.printStackTrace();
       }

   }

   private void WriteEncryptedData1(List<String> Al, List<String> Bl)
   {
    try{
        File f = new File("e1.txt");
        PrintWriter w = new PrintWriter(f,"UTF-8");

       for(int i = 0; i<Bl.size();i++)
       {
           //String A = Al.get(i);
           String B = Bl.get(i);
           
        if(f.exists())
        {
           w.append(B);//.getBytes().toString()+"\n");
           //w.append(A+"..."+B+"\n");
        }
        else
        {
           //System.out.println(A+"..."+B+"\n");
           w.print(B);//.getBytes().toString());
           //w.println(A+"..."+B+"\n");
        }
        }
        w.close();
    }
    catch(IOException e)
    {
        e.printStackTrace();
    }
       
       
    }


    private static void WriteKeysInFile()
    {

        try
        {
            File f = new File("/home//indranil//Desktop//Docs//keys.txt");
            PrintWriter w = new PrintWriter(f,"UTF-8");
            w.println(_gPoint.toString());
            w.println(_hPoint.toString());
            w.println(_g2Point.toString());
            w.println(_a.toString());
            w.println(_p.toString());
            w.println(_key);
            w.println(_IV);
            //w.println(_g1.toString()+"\n");
            //w.println(_e.getGroupOrder()+"\n");

            w.close();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
    
    public void ReadKeys()
    {
        try{

        BufferedReader in = new BufferedReader(new FileReader("/home//indranil//Desktop//Docs//keys.txt"));
        //
        String line; 
        int ln = 1;
		while((line = in.readLine()) != null)
        {
            if( ln <= 3)
            {
                String[] arr=line.split(",");
                String px = new String(arr[0].substring(1));
                int l = arr[1].length();
                String py = arr[1].substring(0,l-1);
                if(ln == 1)
                {
                    _gPoint = new Point(new BigInt(px),new BigInt(py));
                }
                if(ln == 2)
                {
                    _hPoint = new Point(new BigInt(px),new BigInt(py));
                }
                if(ln == 3)
                {
                    _g2Point = new Point(new BigInt(px),new BigInt(py));
                }
            }
            if(ln == 4)
            {
                _a = new BigInt(line);

            }
            if(ln == 5)
            {
                _p = new BigInt(line);
            }
            if(ln == 6)
            {
                _key = new String(line);
            }
            if(ln == 7)
            {
                _IV = new String(line);
            }

            
            ln++;

        }
        in.close();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        //
   
       _e = Predefined.nssTate();
       //the curve on which G1 is defined 
       _g1 = _e.getCurve();
  
       //the curve on which G2 is defined 
       _g2 = _e.getCurve2();
       _iList = new ArrayList<BigInt>();
       _AList = new HashMap<BigInt,Point>();
       _iList.add(new BigInt("0"));
       //
       for(int i = 1;i<=RANGE;i++)
       {
           BigInt obj = new BigInt(Integer.toString(i));
           //
           _iList.add(obj);
           _AList.put(obj,_g1.multiply(_gPoint,obj));
       }
       //
    }
    
    private void ReadData()//List<String> Al, List<String> Bl)
    {
        int c = 0;
        try
        {
            //FileReader fr = new FileReader("e1.txt");
            //BufferedReader br = new BufferedReader(fr);
            //
            File fr = new File("e1.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fr),"UTF-8"));

            //
            String line;

            while(( line = br.readLine()) != null)
            {
                System.out.println(line);
                c++;
                if(c > 1)
                    break;
            }

            br.close();

        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

        
        
   // This function generates trapdoor for the input word 
   // which is a point on curve2, i.e., G2.

    private Point Trapdoor
    (
        String w    // input: word for which trapdoor is tobe formed 
        //Point tr     // out: this is the trapdoor which is a point on curve2 i.e. G2
    )
    {

        try{
            String ss = HMAC(w.getBytes(),_key);
            //BigInt hw = new BigInt(ss.getBytes());
            //Point pt2 = _g2.multiply(_g2Point,hw);
            //Point tr = _g2.multiply(pt2,_a); 
            //
            BigInt hw = new BigInt(ss.getBytes());
            hw = hw.multiply(_a);
            Point tr = _g2.multiply(_g2Point,hw); 

            return tr;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }




public  String HMAC

  (

      byte data[],

          String key

            ) throws Exception

 {
    
    SecretKeySpec sk = new SecretKeySpec(key.getBytes(), "HmacSHA1");

    Mac mc = Mac.getInstance("HmacSHA1");

    mc.init(sk);

    return new String(mc.doFinal(data), "UTF-8");//US-ASCII");

 }



public  byte[] HMAC_byte

  (

      byte data[],

          String key

            ) throws Exception

 {
    
    SecretKeySpec sk = new SecretKeySpec(key.getBytes(), "HmacSHA1");

    Mac mc = Mac.getInstance("HmacSHA1");

    mc.init(sk);

    return mc.doFinal(data); //US-ASCII");

 }


public  void HMAC_byte_copy

  (

      byte data[],

          String key,
          byte hash[]

            ) throws Exception

 {
    
    SecretKeySpec sk = new SecretKeySpec(key.getBytes(), "HmacSHA1");

    Mac mc = Mac.getInstance("HmacSHA1");

    mc.init(sk);

    System.arraycopy(mc.doFinal(data),0,hash,0,20); //US-ASCII");

 }


    public static void foo()
    {
		//System.out.println("Enter the string to be searched:");
    
        //initialise the predifined pairings using the supersingular curve
        //Pairing eSS1 = Predefined.ssTate();
    
    
        Pairing e = Predefined.nssTate();

       //get P, which is a random point in group G1 
       Point P = e.RandomPointInG1(new Random());

       //get Q, which is a random point in group G2 
       Point Q = e.RandomPointInG2(new Random());
       //Point Q = e.RandomPointInG1(new Random());


       //compute e(P,Q)
       FieldElement epq =e.compute(P,Q);

       //the curve on which G1 is defined 
       EllipticCurve g1 = e.getCurve();
      
       //a is a 160-bit random integer
       BigInt a = new BigInt(160,new Random()); 
      
      //Point aP is computed over G1
      Point aP = g1.multiply(P, a);

      // The curve on which G2 is defined

       EllipticCurve g2 = e.getCurve2();
      
       //b is a 160-bit random integer
       BigInt b = new BigInt(160,new Random()); 
      
      //Point bQ is computed over G2
      Point bQ = g2.multiply(Q, b);
      //Point bQ = g1.multiply(Q, b);
     
      FieldElement res = e.compute(aP,bQ);

      BigInt ab = a.multiply(b);
      Field gt = e.getGt();

      FieldElement res2 = gt.pow(epq,ab);

     if(res.equals(res2))
     {
         System.out.println("\nhurreeyyyyyyyyyyy\n");
     }
     ////////////////////////////////////////////////////////////////
     
     
      Point aQ = g2.multiply(Q, a);
      
      FieldElement eapq =e.compute(aP,Q);
      FieldElement epaq =e.compute(P,aQ);
      if(eapq.equals(epaq))
      {
         System.out.println("\nkakaaaaaaaaaaaaaaaaaaaaaaaaa fatafati\n");

      }
     
     
     
     ///////////////////////////////////////////////////////////////
     String s = P.toString();
     int ll = s.length() ;
     String ss = s.substring(1,ll-1);
     System.out.println(s);
     System.out.println(ss);
     byte [] bv = ss.getBytes();
     System.out.println("length is " + bv.length);
     BigInt od = e.getGroupOrder();
     System.out.println("order " + od.toString());
 }                   









}
