package main.java.com.ntotten.csproj;

import org.bouncycastle.asn1.cms.IV;
import org.bouncycastle.crypto.CryptoException;

import javax.crypto.SecretKey;
import java.util.Arrays;

public class Trapdoor {
    // Used to securely search the server-side index for desired value.
    /*
    Trapdoor is a probabilistic algorithm run by the client to generate a trapdoor for a given string of words,
    s = (w_1, w_2, ... , w_l). It takes k_m, k', k_s, p, and s as inputs, and returns
    t = (t_1, t_2, ... , t_i) where t_i is the trapdoor corresponding to the word w_i.
    Since Trapdoor is randomized, we write this as T <-- Trapdoor(k_m, k', k_s, p)(S)

    Ray, I. G., Rahulamathavan, Y., & Rajarajan, M. (2020).
     A New Lightweight Symmetric Searchable Encryption Scheme for String Identification.
     IEEE Transactions on Cloud Computing, 8(3), 672–684.
     https://doi.org/10.1109/TCC.2018.2820014
     */
    public static int[] trapdoor(
            String w,
            SecretKey master_key,
            SecretKey mask_key,
            SecretKey server_key,
            IV iv
            )
            throws Exception
    {
        // TODO - trapdoor function
        // See algo 3 - further analysis needed to build understanding of logic
        long trapdoorStart = System.nanoTime();

        int[] trapdoors = new int[3];

        if (w == null)
        {
            throw new CryptoException("keyword is null");
        }

        String encryptedString = Arrays.toString(Encryption.encryptString(w, iv.getIV(), master_key));
        byte[] mask = HMAC.hMacSHA256(w, mask_key);
        byte[] clientIndex = HMAC.hMacSHA256(w, master_key);

        int trapdoor_1 = Arrays.hashCode(HMAC.hMacSHA256(encryptedString + mask + clientIndex, server_key));
        int trapdoor_2 = encryptedString.hashCode() * Arrays.hashCode(clientIndex);
        int trapdoor_3 = encryptedString.hashCode() * Arrays.hashCode(mask);

        long trapdoorEnd = System.nanoTime();
        double elapsedTime = (trapdoorEnd - trapdoorStart) / 1000000.0;
        System.out.println("Trapdoor generation time : " + elapsedTime + " ms.\n");

        trapdoors[0] = trapdoor_1;
        trapdoors[1] = trapdoor_2;
        trapdoors[2] = trapdoor_3;

        return trapdoors;
    }
}
