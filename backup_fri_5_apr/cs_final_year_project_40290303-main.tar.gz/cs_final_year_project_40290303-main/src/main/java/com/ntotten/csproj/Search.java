package main.java.com.ntotten.csproj;

import java.math.BigInteger;
import java.util.ArrayList;

public class Search {
    /*
    Search is run by the server in order to search for the documents in D that contain the string s.
    It takes k_s, SI and trapdoor t of the string s as inputs, and returns D(s),
    the set of identifiers of documents containing the string s.
    Since this algorithm is deterministic, we write it as D(s) = Search_k_s(SI, t)

    Ray, I. G., Rahulamathavan, Y., & Rajarajan, M. (2020).
     A New Lightweight Symmetric Searchable Encryption Scheme for String Identification.
     IEEE Transactions on Cloud Computing, 8(3), 672–684.
     https://doi.org/10.1109/TCC.2018.2820014
     */
    public static ArrayList<byte[]> searchForKeyword(String keyWord) {
        // TODO - Search functionality

        //

        // Will return a list of the encrypted file identifiers - in this instance each encrypted ID is a byte[]
        return null; // placeholder.
    }

}
