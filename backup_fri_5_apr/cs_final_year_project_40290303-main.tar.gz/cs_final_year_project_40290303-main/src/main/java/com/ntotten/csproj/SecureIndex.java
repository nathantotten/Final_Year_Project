package main.java.com.ntotten.csproj;

import uk.ac.ic.doc.jpair.pairing.BigInt;

import javax.crypto.SecretKey;
import java.util.*;
    /*
    BuildIndex is a probabilistic algorithm run by the client to generate SI = (I, I_r, I_c).
    It takes k_m, k', k_s, p and returns SI.
    Since BuildIndex is randomized, we write this as SI <-- BuildIndex(k_m, k', k_s, p)(S)

    Ray, I. G., Rahulamathavan, Y., & Rajarajan, M. (2020).
     A New Lightweight Symmetric Searchable Encryption Scheme for String Identification.
     IEEE Transactions on Cloud Computing, 8(3), 672–684.
     https://doi.org/10.1109/TCC.2018.2820014
     */
public class SecureIndex {

    private static final ArrayList<BigInt> I_r = new ArrayList<>();     // Row index - stores encrypted file identifiers.
    private static final ArrayList<BigInt> I_c = new ArrayList<>();     // Column index - stores ci values (inverse modulo of hashed keywords).
    private static final ArrayList<BigInt> I = new ArrayList<>();       // Index - stores encrypted file identifiers and ci values.SI;

    public SecureIndex() {
    }

    public static void buildIndex (SecretKey k_m, SecretKey k_0, SecretKey k_s, BigInt prime, HashMap<String, ArrayList<String>> documentCollection )
        throws Exception
    {
        // TODO - form a collection of all keywords in the document collection.
        // Each file obj is a .txt file with some data.
        // What will allow us to determine the keywords? User specifying key words would be much too tedious surely...
        //  BINGO - how could I have forgotten to just use a bloody set for ensuring only distinct words get stored...
        HashSet<String> uniqueWordCollection = formDistinctWordCollection(documentCollection);
        // Print the unique words
        for (String w : uniqueWordCollection)
            System.out.println(w);

        // TODO - Initialise Data Structures I_r and I_c

        // TODO - Initialise Data Structure SI, the matrix.







        byte[] clientIndex = HMAC.hMacSHA256("Nathan", k_m);
        BigInt ci = new BigInt(clientIndex);
        System.out.println("Client Index: " + ci + "\n");






        // Unsure?
        byte[] hmac = HMAC.hMacSHA256("Nathan", k_m);
        String hmacString = Base64.getEncoder().encodeToString(hmac);
        System.out.println("\nHMAC: " + hmacString);
        //return secureIndex;
    }

    private static HashSet<String> formDistinctWordCollection(HashMap<String, ArrayList<String>> documentCollection)
    {
        HashSet<String> uniqueWords = new HashSet<>();
        // Iterate over each value in documentCollection
        //  THEN iterate over each line of each value and save the words you encounter into the uniqueWords hashset.
        // This feels like it will be VERY slow...
        for (ArrayList<String> file : documentCollection.values()) {
            for (String line : file) {
                String[] words = line.replaceAll("[^\\w\\s]", "").split("\\s+");
                uniqueWords.addAll(Arrays.asList(words));
            }
        }
        return uniqueWords;
    }

    public static void printIndexTable() {
        // TODO - Find a way to nicely print and display the table
    }
}
