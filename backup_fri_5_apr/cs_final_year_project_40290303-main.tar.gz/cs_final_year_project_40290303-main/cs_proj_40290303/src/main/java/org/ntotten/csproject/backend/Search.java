/*
 * Copyright (c) 2024.
 * Nathan Totten - 40290303 - SSE Final Year Project
 */

package org.ntotten.csproject.backend;

import javax.crypto.SecretKey;
import java.math.BigInteger;
import java.util.ArrayList;

public class Search {
    public static ArrayList<BigInteger> search(String keyWord) {

        if (keyWord.isEmpty()) {
            System.err.println("Invalid search : key word is null or empty!");
            return null;
        }

        BigInteger[][] serverIndex = ServerIndex.getServerIndex();
        SecretKey server_key = Encryption.getServerKey();
        BigInteger prime = Encryption.getPrime();
        ArrayList<BigInteger> I_r = ServerIndex.getI_row();
        ArrayList<BigInteger> I_c = ServerIndex.getI_column();

        BigInteger[] trapdoors = Trapdoor.generateTrapdoors(keyWord, server_key);
        BigInteger trapdoor_1 = trapdoors[0];
        BigInteger trapdoor_2 = trapdoors[1];
        BigInteger trapdoor_3 = trapdoors[2];

        // Return value
        ArrayList<BigInteger> encryptedFileNames = new ArrayList<>();

        // When we do the comparison to check which column to search over (which j for I_r[j] do we want to focus on)
        // We will loop over the values in I_r[] and run this comparison on each:
        // It foes as follows: if ( t_1 == HMAC_ks([e + msk + I_r[j]^-1] (mod prime) ) ) then set int column ptr as j.

        BigInteger e = null;
        BigInteger msk = null;
        int columnPointer = 0;
        int size = I_r.size();
        /*
        *   TODO : Figure out how to split the size param here into chunks and assign each
        *       chunk to a thread.
        *       Implement a multi-threaded approach to searching over I_r to try and speed up this portion of searching
        */

        // For each word in I_r[]
        for (int j = 0; j < size; j++) {
            // Calculate e and msk
            // e = t_2 x I_r[j] (mod prime)
            e = trapdoor_2.multiply(I_r.get(j));
            e = e.mod(prime);

            // msk = (t_3 x e^-1(mod prime)) (mod prime)
            BigInteger inverseModE = e.modInverse(prime).mod(prime);
            msk = trapdoor_3.multiply(inverseModE);
            msk = msk.mod(prime);

            // Find modular inverse of I_r[j] => (I_r[j]^-1)(mod prime)
            BigInteger valueAtJ = I_r.get(j);
            BigInteger modularInverseIrJ = valueAtJ.modInverse(prime);
            modularInverseIrJ = modularInverseIrJ.mod(prime);

            // Sum: e + msk + modInverseIrJ (mod prime)
            BigInteger sumValues = (e.add(msk).add(modularInverseIrJ));
            sumValues = sumValues.mod(prime);

            // Convert result of (e + msk + I_r[j]^-1) to String
            byte[] sumBytes = sumValues.toByteArray();
            String sumString = new String(sumBytes);

            // HMAC with server key
            BigInteger resultBigInt = new BigInteger(HMAC.hMacSHA256(sumString, server_key)).mod(prime);

            // Check if the values are equal - if yes, save the pointer we are at and break out.
            if (resultBigInt.equals(trapdoor_1)) {
                //System.out.println("Match for keyword found at position: " + j);
                columnPointer = j;
                break;
            }
            // This loop appears to be doing its job!
        }

        // When we do the comparison that checks if a value at SI[i][j] is present/matching
        //  It goes as follows: if ( [e + msk](mod prime) == I[i][col] ) then add I_c[i] to the list of encrypted file pointers to be returned.
        size = I_c.size();

        /*
        * TODO :
        *   Implement multi-threaded search here for performance gains - see Concurrent Programming material!
        */

        for (int i = 0; i < size; i++) {
            assert e != null : "e value is null!";
            assert msk != null : "mask value is null!";

            //System.out.println("col pointer: " + columnPointer);

            BigInteger sum = e.mod(prime).add(msk).mod(prime);
            //System.out.println("sum: " + sum);
            BigInteger valueToCheck = serverIndex[i][columnPointer];
            //System.out.println("value to check: " + valueToCheck);

            if (sum.equals(valueToCheck)) {
                //System.out.println("Match found at position: SI[" + i + "][" + columnPointer + "]");
                encryptedFileNames.add(I_c.get(i));
            }
        }

        if (encryptedFileNames.isEmpty()) {
            System.err.println("No matching files found :( ");
        } else {
            System.out.println("Search successful! :) ");
        }
        return encryptedFileNames;
    }
}
