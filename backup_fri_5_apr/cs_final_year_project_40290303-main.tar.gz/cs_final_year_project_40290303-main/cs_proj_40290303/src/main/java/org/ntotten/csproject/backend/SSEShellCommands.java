/*
 * Copyright (c) 2024.
 * Nathan Totten - 40290303 - SSE Final Year Project
 */

package org.ntotten.csproject.backend;

import org.ntotten.csproject.backend.shell.InputReader;
import org.ntotten.csproject.backend.shell.ShellHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;
import org.springframework.util.StringUtils;

import javax.print.Doc;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import static java.nio.charset.StandardCharsets.UTF_8;

@ShellComponent
public class SSEShellCommands {

    @Autowired
    ShellHelper shellHelper;

    @Autowired
    InputReader inputReader;

    private static ArrayList<String> searchResults = new ArrayList<>();

    @ShellMethod(value = "This command generates the required encryption keys.", key = "generate-keys")
    public void keyGen() {
        Encryption.generateKeys();
    }

    @ShellMethod(value = "This command is used to upload a specific file.", key = "upload-file")
    public void uploadFile() {
        String path;
        do {
            path = inputReader.prompt("Enter the path to the file you wish to upload: ");

        } while (path.isEmpty());

        try {
            DocumentUtility.readFileFromDir(path, shellHelper);
        } catch (Exception e) {
            shellHelper.printError("Error uploading file: " + e.getMessage());
        }
    }

    @ShellMethod(value = "This command is used to upload all files at a specified directory.", key = "upload-all-files")
    public void uploadFiles() {
        String dir;
        do {
            dir = inputReader.prompt("Enter the path to the files you wish to upload: ");
        } while (dir.isEmpty());

        try {
            DocumentUtility.readAllFilesFromDir(dir, shellHelper);
        } catch (Exception e) {
            shellHelper.printError("Error uploading files: " + e.getMessage());
        }
    }

    @ShellMethod(value = "This command is used to search for the provided keyword.", key = "search")
    public void search() throws Exception {
        ServerIndex.buildIndex();

        String keyWord = inputReader.prompt("Please enter the keyword you wish to search for: ");

        ArrayList<BigInteger> encryptedResults = Search.search(keyWord);

        assert encryptedResults != null : "No matches! Null search results.";


        if (!encryptedResults.isEmpty()) {
            shellHelper.printSuccess("Search was successful!");
            shellHelper.printInfo("Matching files:");
            for (BigInteger encrypted : encryptedResults) {
                byte[] encryptedBytes = encrypted.toByteArray();
                String plaintext = new String(Encryption.decryptString(encryptedBytes, Encryption.getOwnerKey()), UTF_8);
                searchResults.add(plaintext);
                shellHelper.printInfo(plaintext);
            }
        }
    }
}
