/*
 * Copyright (c) 2024.
 * Nathan Totten - 40290303 - SSE Final Year Project
 */

package org.ntotten.csproject.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.io.Console;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.CharBuffer;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.nio.charset.StandardCharsets.UTF_8;

// The main class.
@SpringBootApplication
public class Main {
    private static ArrayList<String> searchResults = new ArrayList<>();
    private static final String CREATE_DOCUMENTS_TABLE = "CREATE TABLE IF NOT EXISTS encrypted_documents" +
                                                                "(" +
                                                                "document_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                                                "encrypted_file_name BLOB," +
                                                                "encrypted_data BLOB" +
                                                                ")";

    public static void main(String[] args) {

        SpringApplication.run(Main.class, args);

        //initDB();
        /*System.out.println("Hello! Welcome to this demo of some of the basic functionality of this encryption scheme.\n");
        Scanner inputScanner = new Scanner(System.in);
        int choice;

        do {
            displayMenu();
            System.out.print("Enter your choice: ");
            choice = inputScanner.nextInt();

            switch (choice) {
                case 1:     // Key Generation.
                    Encryption.generateKeys();
                    break;

                case 2:     // File Upload.
                    fileUpload(inputScanner);
                    break;

                case 3:     // Export Keys.
                    System.err.println("Currently unsupported!");
                    //exportKeys();
                    break;

                case 4:     // Decrypt Docs.
                    // TODO : update to decrypt a specified doc
                    break;

                case 5:     // Search through encrypted data.
                    ServerIndex.buildIndex();
                    search(inputScanner);
                    break;

                case 6:    // Exit.
                    System.out.println("Exiting SSE Demo...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);
        inputScanner.close();
        System.exit(0);*/
    }

    private static void initDB() {
        // Encapsulate connection and statement resources for better management
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database/sse.db");
             Statement statement = connection.createStatement()) {
            System.out.println("Connection to SQLite database established.");
            // Create tables, handling errors with informative messages
            createTable(statement, CREATE_DOCUMENTS_TABLE, "documents");
        } catch (SQLException e) {
            System.err.println("Error during database initialization: " + e.getMessage());
            throw new IllegalStateException("Database initialization failed", e);
        }
    }

    private static void createTable(Statement statement, String createTableSQL, String tableName) throws SQLException {
        try {
            statement.execute(createTableSQL);
            System.out.println("Table '" + tableName + "' successfully created!");
        } catch (SQLException e) {
            System.err.println("Error creating table '" + tableName + "': " + e.getMessage());
            if (!"table already exists".equalsIgnoreCase(e.getMessage().trim())) {
                throw e; // Rethrow if not a duplicate table error
            }
        }
    }

    private static void displayMenu()
    {
        System.out.println("Menu:");
        System.out.println("[ 1 ]  Generate Encryption Keys.");             // DONE
        System.out.println("[ 2 ]  Upload File(s) To Be Encrypted.");       // DONE
        System.out.println("[ 3 ]  Export Encryption Keys. ");              // DONE
        System.out.println("[ 4 ]  Decrypt Documents.");                    // A request to download a document that is returned by a search should do this automatically.
        System.out.println("[ 5 ]  Search.");                               // DONE
        System.out.println("[ 6 ]  Exit.");                                 // Self-explanatory.
    }

    private static void search(Scanner scanner) throws Exception {
        System.out.println("Enter the key word to search for: ");
        String keyWord = scanner.next();

        ArrayList<BigInteger> encryptedResults = Search.search(keyWord);

        assert encryptedResults != null : "No matches! Null search results.";

        System.out.println("Matching files:");
        for (BigInteger encrypted : encryptedResults) {
            byte[] encryptedBytes = encrypted.toByteArray();
            String plaintext = new String(Encryption.decryptString(encryptedBytes, Encryption.getOwnerKey()), UTF_8);
            searchResults.add(plaintext);
            System.out.println(plaintext);
        }

    }

    private static void retrieveDocument(String fileName) {
        // User provides the fileName based on results of search - which will return fileIDs of documents matching search word.
        // It is assumed that if the user wishes to retrieve the file matching this fileName from the db, that they will want it decrypted.
        // System grabs the encrypted BLOB from the database into memory (without decrypting it in DB).
        // This data is then returned to the user and decrypted automatically before being output to the user's file system as a .txt file.
        // User should not have to manually decrypt a file that they request.
        // Database/server should *never* see the plaintext file.
    }

    private static void fileUpload(Scanner scanner) throws NoSuchAlgorithmException {
        int fileOperation;
        do {
            System.out.println("Please choose a file upload option:");
            System.out.println("[ 1 ] Upload and encrypt a specific file.");
            System.out.println("[ 2 ] Upload and encrypt all files from a directory.");
            System.out.println("[ 3 ] Exit to main menu.");
            fileOperation = scanner.nextInt();
            String dir;
            switch (fileOperation) {

                case 1: // Single file upload.
                    System.out.println("Please enter the path to the file to upload:");
                    dir = scanner.next();
                    //DocumentUtility.readFileFromDir(dir);
                    break;

                case 2: // Multi-file upload.
                    System.out.println("Please enter the directory of the files to upload:");
                    dir = scanner.next();
                    //DocumentUtility.readAllFilesFromDir(dir);
                    break;

                case 3: // Exit to main menu.
                    System.out.println("Exiting to main menu...");
                    break;
                default:
                    System.out.println("Invalid input. Please try again.");
            }
        } while (fileOperation != 3);
    }

    private static void exportKeys()
    {
        try {
            System.out.println("Exporting Encryption Keys to secure Key Store...");
            // TODO : Find alternative that works in IDE?
            Console console = System.console(); // Grab console for reading in password.
            boolean validPword = false; // Default valid password to false.
            String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=£!*_])(?=\\S+$).{8,30}$"; // Set regex to validate password.
            Pattern pattern = Pattern.compile(regex);

            while (!validPword) {
                System.out.println("Please enter a secure password for key storage (You may wish to store this in a password manager of your choosing!) : ");
                // NOTE: Only works when compiled and executed in a true shell - does not work in IDEs.
                char[] rawPassword = console.readPassword();

                CharBuffer passwordBuffer = CharBuffer.wrap(rawPassword);
                Matcher matcher = pattern.matcher(passwordBuffer);
                validPword = matcher.matches();
                if (validPword) {
                    Encryption.exportKeysToKeyStore(rawPassword);
                } else {
                    System.err.println("Invalid password!");
                }
            }

        } catch (CertificateException | NoSuchAlgorithmException | KeyStoreException | IOException e) {
            System.err.println("Error exporting keys : " + e.getMessage());
            throw new RuntimeException(e);
        }
    }
}
