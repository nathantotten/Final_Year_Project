/*
 * Copyright (c) 2024.
 * Nathan Totten - 40290303 - SSE Final Year Project
 */

package org.ntotten.csproject.backend;

import org.ntotten.csproject.backend.shell.ShellHelper;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.stream.Stream;

public class DocumentUtility{
    private static final HashMap<byte[], HashSet<String>> mapOfFilesToWordSets = new HashMap<>();
    private static final HashSet<String> allUniqueWords = new HashSet<>();

    public static boolean isValidFilePath(String filePath) {
        try {
            Path path = Paths.get(filePath);
            return Files.exists(path);
        } catch (InvalidPathException | NullPointerException ex) {
            System.err.println(ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

    public static boolean isValidDir(String dirPath) {
        try {
            Path directory = Paths.get(dirPath);
            return Files.isDirectory(directory);
        } catch (InvalidPathException | NullPointerException ex) {
            System.err.println(ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

    public static boolean readFileFromDir(String pathStr, ShellHelper shellHelper) throws NoSuchAlgorithmException {

        if (!isValidFilePath(pathStr)) {
            System.err.println(pathStr + " is not a valid file path!");
            return false;
        }

        Path path = Paths.get(pathStr);

        // Check filepath is valid text file
        if (!Files.isRegularFile(path) || !path.toString().toLowerCase().endsWith(".txt")) {
            System.err.println("File is not a valid .txt file.");
            return false;
        }

        // Check if keys are null
        if (!checkKeys(shellHelper)) {
            return false;
        }

        StringBuilder stringBuilder = new StringBuilder();
        HashSet<String> fileSpecificWordSet = new HashSet<>();

        try ( BufferedReader br = Files.newBufferedReader(path) ) {

            while (br.ready()) {
                String line = br.readLine();
                stringBuilder.append(line).append("\n");
                String[] words = line.replaceAll("[^\\w\\s]", "").toLowerCase().split("\\s+");
                allUniqueWords.addAll(Arrays.asList(words));
                fileSpecificWordSet.addAll(Arrays.asList(words));
            }

            // Encrypt the string builder object (that at this point contains all the lines of the file) using the master key
            byte[] encryptedContent = Encryption.encryptString(stringBuilder.toString(), Encryption.getOwnerKey(), Encryption.generateInitialisationVector());
            byte[] encryptedFileName = Encryption.encryptString(path.getFileName().toString(), Encryption.getOwnerKey(), Encryption.generateInitialisationVector());
            // This map of fileNames to file-specific word sets is used for generating the Server Index.
            mapOfFilesToWordSets.put(encryptedFileName, fileSpecificWordSet);
            // Here, the database stands as an analogue for the server - storing the encrypted files.
            //writeEncryptedFileDataToDB(encryptedFileName, encryptedContent);
            shellHelper.printSuccess("File " + path.getFileName() + " successfully uploaded!");
            return true;
        } catch ( Exception ex ) {
            System.err.println("Error reading file : " + ex.getMessage());
            shellHelper.printError("Error reading file : " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

    public static boolean checkKeys(ShellHelper shellHelper) {
        if (
                Encryption.getPrime() == null ||
                Encryption.getServerKey() == null ||
                Encryption.getOwnerKey() == null ||
                Encryption.getMaskKey() == null
        ) {
            // Do I want to stop the user and tell them they have not provided keys?
            shellHelper.printWarning("Encryption keys could not be found! Please generate encryption keys first.");
            return false;
        } else {
            return true;
        }
    }

    public static void readAllFilesFromDir(String pathStr, ShellHelper shellHelper) {

        if (!isValidDir(pathStr)) {
            System.err.println(pathStr + " is not a valid directory!");
            return;
        }

        Path path = Paths.get(pathStr);

        try (Stream<Path> filePaths = Files.list(path)) {
            filePaths.forEach(filePath -> {
                try {
                    readFileFromDir(filePath.toString(), shellHelper);
                } catch (NoSuchAlgorithmException e) {
                    System.err.println(e.getMessage());
                }
            });
        } catch (IOException ex) {
            System.err.println("Unable to read files from directory : " + ex.getMessage());
            shellHelper.printError("Unable to read files from directory : " + ex.getMessage());
        }
    }

    public static HashSet<String> getAllUniqueWords() {
        return allUniqueWords;
    }

    public static HashMap<byte[], HashSet<String>> getMapOfFilesToWordSets() {
        return mapOfFilesToWordSets;
    }

    public static void writeEncryptedFileDataToDB(byte[] fileName, byte[] encryptedFile) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database/sse.db");
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO encrypted_documents (encrypted_file_name, encrypted_data) VALUES (?, ?)")) {

            preparedStatement.setBytes(1, fileName);
            preparedStatement.setBytes(2, encryptedFile);
            preparedStatement.executeUpdate();

        } catch (SQLException ex) {
            System.err.println("Error storing encrypted file data : " + ex.getMessage());
        }
    }

    public static byte[] retrieveEncryptedFileDataFromDB(byte[] encryptedFileName) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:database/sse.db");
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT encrypted_data FROM encrypted_documents WHERE encrypted_file_name = ?")) {
            preparedStatement.setBytes(1, encryptedFileName);
            ResultSet encryptedFile = preparedStatement.executeQuery();
            return encryptedFile.getBytes(1);
        } catch (SQLException ex) {
            System.err.println("Error storing encrypted file data");
            return null;
        }
    }

    public static void writeToFile() {
        // TODO - Figure out how to write a returned search result to file if user wants it. Could also use this for keys?
    }
}
