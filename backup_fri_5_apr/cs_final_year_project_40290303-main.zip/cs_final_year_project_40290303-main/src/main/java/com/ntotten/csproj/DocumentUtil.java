package main.java.com.ntotten.csproj;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.stream.Stream;

public class DocumentUtil {
    private static final HashMap<String, ArrayList<String>> documentCollection = new HashMap<>();
    private static final ArrayList<String> file = new ArrayList<>();
    private static int fileID = 0;

    public static void readFileFromDir(String path)
    {
        try ( BufferedReader br = Files.newBufferedReader(Paths.get(path)) ) {
            while (br.ready()) {
                String line = br.readLine();
                // Let user know what is happening - troubleshooting.
                //System.out.println(line);
                file.add(line);
            }
        } catch ( IOException e ) {
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
        addFileToCollection(file);
    }

    public static void readAllFilesFromDir(String path) {
        try (Stream<Path> filePaths = Files.list(Paths.get(path))) {
            filePaths.forEach(filePath -> readFileFromDir(filePath.toString()));
        } catch (IOException e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }

    public static void addFileToCollection(ArrayList<String> file)
    {
        documentCollection.put(String.valueOf(fileID), file);
        fileID++;
    }

    public static HashMap<String, ArrayList<String>> getDocumentCollection()
    {
        return documentCollection;
    }
}