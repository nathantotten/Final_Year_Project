package main.java.com.ntotten.csproj;

import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.macs.HMac;
import org.bouncycastle.crypto.params.KeyParameter;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class HMAC {
    // Using BouncyCastle

    // HMAC(message, Key) = H(K XOR opad, H(K XOR ipad, message))
    // where H is SHA-256 and K is the key
    public static byte[] hMacSHA256(String data, SecretKey key)
    {
        long hmacStartTime = System.nanoTime();

        HMac hMac = new HMac(new SHA256Digest());
        hMac.init(new KeyParameter(key.getEncoded()));

        byte[] hmacInput = data.getBytes();
        hMac.update(hmacInput, 0, hmacInput.length);

        byte[] hmacOutput = new byte[hMac.getMacSize()];
        hMac.doFinal(hmacOutput, 0);

        long hmacEndTime = System.nanoTime();
        double elapsed = (hmacEndTime - hmacStartTime) / 1000000.0;
        System.out.println("HMAC-256 Generation Time : " + elapsed + " ms.\n");

        return hmacOutput;
    }

    @Deprecated
    // Unlikely to be used - opting for BouncyCastle instead.
    public static byte[] hmacSHA256(String data, SecretKey key)
        throws NoSuchAlgorithmException, InvalidKeyException
    {
        Mac sha256HMAC = Mac.getInstance("HmacSHA256");
        sha256HMAC.init(key);
        return sha256HMAC.doFinal(data.getBytes());
    }

    @Deprecated
    public static String getHmacHexStr(byte[] hash) {
        // setup string builder
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        // Grab each byte in the provided hash
        for (byte h : hash) {
            // Convert byte to hex String
            String hex = Integer.toHexString(0xff & h);
            // Formatting
            if (hex.length() == 1)
                hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}
