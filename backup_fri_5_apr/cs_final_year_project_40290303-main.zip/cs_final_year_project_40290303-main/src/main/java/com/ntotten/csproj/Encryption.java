package main.java.com.ntotten.csproj;

import uk.ac.ic.doc.jpair.pairing.BigInt;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;

import static java.nio.charset.StandardCharsets.UTF_8;

public class Encryption {
    private static final String ALGORITHM = "AES";
    private static final String CIPHER_ALGORITHM = "AES/GCM/NoPadding";
    private static final int KEY_SIZE = 256;
    private static final int TAG_LENGTH = 128;

    // Random prime.
    private static BigInt prime;
    // Master key for user/data owner. Used to decrypt plaintext data.
    private static SecretKey k_m;
    // Mask key for use with secure index table. Hashing to apply mask.
    private static SecretKey k_0;
    // Session key that will be exposed to the server. Cannot be used to decrypt the data.
    private static SecretKey k_s;

    // Subject to change - unsure of most suitable data structure at this time.
    private static HashMap<String,Integer> secureIndex;

    public Encryption() {
    }

    public static SecretKey getK_m() {
        return k_m;
    }

    public static SecretKey getK_0() {
        return k_0;
    }

    public static SecretKey getK_s() {
        return k_s;
    }

    public static BigInt getPrime() {
        return prime;
    }

    /*
    KeyGen is a probabilistic key generation algorithm that is run by the client to setup the scheme (see Algorithm 1).
     It takes a security parameter lambda, and returns a secret master key k_m and a mask-key k', which are to
     be kept privately at client’s end and a session key k_s which is to be shared between client and the server.
    Client also shares a lambda-bit prime p with the server.
    The length of k_m, k' and k_s are polynomially bounded in lambda.

    Ray, I. G., Rahulamathavan, Y., & Rajarajan, M. (2020).
     A New Lightweight Symmetric Searchable Encryption Scheme for String Identification.
     IEEE Transactions on Cloud Computing, 8(3), 672–684.
     https://doi.org/10.1109/TCC.2018.2820014
     */
    public static void KeyGen() throws NoSuchAlgorithmException {
        // Tell user what is happening.
        System.out.println("KeyGen: Generating encryption keys...\n");
        long keyGenStart = System.nanoTime();

        // Setup Key generator.
        KeyGenerator keyGen = KeyGenerator.getInstance(ALGORITHM);
        keyGen.init(KEY_SIZE, SecureRandom.getInstanceStrong());

        // Create the keys we need.
        // Master Key
        k_m = keyGen.generateKey();

        // Mask Key
        k_0 = keyGen.generateKey();

        // Session/Server Key
        k_s = keyGen.generateKey();

        // Create a random prime number using probabilistic prime number generator.
        prime = BigInt.probablePrime(160, new SecureRandom());

        long keyGenEnd = System.nanoTime();
        double elapsedTime = (keyGenEnd - keyGenStart) / 1000000.0;
        System.out.println("KeyGen: Encryption keys generated!\n");
        System.out.println("KeyGen: Key generation took " + elapsedTime + " ms.\n");

    }

    // Encrypt text with a chosen algorithm, secret key, and initialisation vector.
    public static byte[] encryptString(String plaintext, byte[] iv, SecretKey secretKey)
            throws Exception
    {
        return cryptoOperation(plaintext.getBytes(UTF_8), iv, secretKey, Cipher.ENCRYPT_MODE);
    }

    public static byte[] decryptString(byte[] ciphertext, byte[] iv, SecretKey secretKey)
            throws Exception
    {
        return cryptoOperation(ciphertext, iv, secretKey, Cipher.DECRYPT_MODE);
    }

    private static byte[] cryptoOperation(byte[] text, byte[] iv, SecretKey secretKey, int mode)
            throws Exception
    {
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(TAG_LENGTH, iv);
        cipher.init(mode, secretKey, gcmParameterSpec);
        return cipher.doFinal(text);
    }

    public static void exportKeysToFile()
    {
        String encodedK_m = Base64.getEncoder().encodeToString(k_m.getEncoded());
        String encodedK_0 = Base64.getEncoder().encodeToString(k_0.getEncoded());
        String encodedK_s = Base64.getEncoder().encodeToString(k_s.getEncoded());
        try
        {
            File f = new File("EncryptionKeys.txt");
            PrintWriter w = new PrintWriter(f, UTF_8);
            w.println(encodedK_m); // Master Key
            w.println(encodedK_0); // Mask Key
            w.println(encodedK_s); // Session/Server Key
            w.println(prime.toString()); // Probabilistic Prime
            w.close();
        }
        catch(IOException e)
        {
            System.err.println("Error exporting encryption keys!\n");
            System.err.println(e.getMessage());
        }
    }
}
