package main.java.com.ntotten.csproj;

import org.bouncycastle.asn1.cms.IV;
import uk.ac.ic.doc.jpair.pairing.BigInt;

import javax.crypto.SecretKey;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Scanner;

import static java.nio.charset.StandardCharsets.UTF_8;

// The main class.
public class Main {
    public static void main(String[] args)
            throws Exception
    {
        System.out.println(System.getProperty("user.dir") + "\n");
        String plainText = "Nathan Totten";
        System.out.println("Hello! Welcome to this demo of some of the basic functionality of this encryption scheme.\n");

        // Demo key generation.
        demoKeyGeneration();

        SecretKey master_key = Encryption.getK_m();
        SecretKey mask_key = Encryption.getK_0();
        SecretKey session_key = Encryption.getK_s();
        BigInt prime = Encryption.getPrime();

        // Demo IV generation
        IV initVector = demoIV();

        // Demo Encryption
        demoEncryption(plainText, initVector, master_key);

        // Demo BuildIndex.
        demoBuildIndex(master_key, mask_key, session_key, prime);

        // Demo Trapdoor Generation.
        demoTrapdoor(plainText, master_key, mask_key, session_key, initVector);

        // Demo HMAC.
        demoHMAC(plainText, master_key);
    }

    private static void demoBuildIndex(SecretKey masterKey, SecretKey maskKey, SecretKey serverKey, BigInt bigPrime) throws Exception {
        Scanner inputScanner = new Scanner(System.in);
        HashMap<String, ArrayList<String>> documentCollection = new HashMap<>();
        boolean validInput = false;

        System.out.println("======== BuildIndex Demo ========\n");

        while (!validInput) {
            System.out.println("Would you like to (A) read a specific text file, or (B) read all text files from a specific directory?\n");
            System.out.println("A - Read specific text file from specified path.");
            System.out.println("B - Read all available text files from specified directory.");
            System.out.println("Enter your selection: \n");
            String userSelection = inputScanner.next();

            switch (userSelection.toUpperCase())
            {
                case "A":
                    // Call method for option A.
                    validInput = true;
                    System.out.println("You selected option A.\n");
                    readSpecificFileFromDir(inputScanner);
                    documentCollection = DocumentUtil.getDocumentCollection();
                    break;

                case "B":
                    // Call method for option B.
                    validInput = true;
                    System.out.println("You selected option B.\n");
                    readAllFilesInDir(inputScanner);
                    documentCollection = DocumentUtil.getDocumentCollection();
                    break;

                default:
                    System.out.println("Invalid input - please select either A or B\n");
                    break;
            }
        }
        inputScanner.close();

        System.out.println("Building Secure Index...\n");
        SecureIndex.buildIndex(masterKey, maskKey, serverKey, bigPrime, documentCollection);
        System.out.println("Secure Index Generation Complete!\n");
        System.out.println("Secure Index is being printed...\n");
        SecureIndex.printIndexTable();
        System.out.println("Secure Index Printed!\n");
    }

    private static void readAllFilesInDir(Scanner scanner) {
        // Get the path to the file from the user.
        System.out.println("Enter the path to the directory: \n");
        String pathToFiles = scanner.next();
        // Read in all files in the directory.
        DocumentUtil.readAllFilesFromDir(pathToFiles);
    }

    private static void readSpecificFileFromDir(Scanner scanner) {
        // Get the path to the file from the user.
        System.out.println("Enter the path to the file: \n");
        String pathToSingleFile = scanner.next();
        // Read in the specified .txt file at the specified file path - return an error if none found.
        // Read file.
        DocumentUtil.readFileFromDir(pathToSingleFile);
    }

    private static void demoHMAC(String plainText, SecretKey master_key) throws NoSuchAlgorithmException, InvalidKeyException {
        System.out.println("======== HMAC Generation Demo ========\n");
        // Demo HMAC Generation
        System.out.println("Generating HMAC...\n");

        byte[] hmac = HMAC.hMacSHA256(plainText, master_key);
        String hmacString = Base64.getEncoder().encodeToString(hmac);

        System.out.println("HMAC Generated : " + hmacString + "\n");

        System.out.println("======== ALL DONE! ========\n");
    }

    private static void demoTrapdoor(String plainText, SecretKey master_key, SecretKey mask_key, SecretKey session_key, IV initVector) throws Exception {
        System.out.println("======== Trapdoor Generation Demo ========\n");
        System.out.println("Building trapdoors...");
        int[] trapdoors = Trapdoor.trapdoor(plainText, master_key, mask_key, session_key, initVector);
        System.out.println("Trapdoors are being printed...");

        for (int trapdoor : trapdoors)
        {
            System.out.println(trapdoor);
        }

        System.out.println("Trapdoors Generated!\n");
    }

    private static void demoEncryption(String plainText, IV initVector, SecretKey master_key) throws Exception {
        System.out.println("\n======== Encryption and Decryption Demo ========");

        System.out.println("\nPlain Text : " + plainText);

        // ciphertext
        byte[] cipherText = Encryption.encryptString(plainText, initVector.getIV(), master_key);

        // Let user know what is happening...
        System.out.println("Encrypted Text : " + Base64.getEncoder().encodeToString(cipherText));

        String decryptedText = new String(Encryption.decryptString(cipherText, initVector.getIV(), master_key), UTF_8);
        System.out.println("Decrypted Text : " + decryptedText);

        // Compare decrypted ciphertext to original plaintext
        if (decryptedText.equals(plainText)) {
            System.out.println("successful!\n");
        } else {
            System.out.println("Unsuccessful :( \n");
        }
    }

    private static IV demoIV() {
        System.out.println("======== Initialisation Value Generation Demo ========\n");
        IV initVector = InitialisationVector.generateIV();
        String initVectorString = Base64.getEncoder().encodeToString(initVector.getIV());
        System.out.println("Generated Initialisation Value : " + initVectorString);
        return initVector;
    }

    private static void demoKeyGeneration() throws NoSuchAlgorithmException {
        // Demo Key Generation
        System.out.println("======== Key Generation Demo ========\n");
        Encryption.KeyGen();

        System.out.println("Exporting keys...");
        Encryption.exportKeysToFile();
        System.out.println("Keys exported!\n");
    }
}
