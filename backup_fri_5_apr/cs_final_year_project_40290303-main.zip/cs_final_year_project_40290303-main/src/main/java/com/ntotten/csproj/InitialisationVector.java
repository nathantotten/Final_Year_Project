package main.java.com.ntotten.csproj;

import org.bouncycastle.asn1.cms.IV;

import java.security.SecureRandom;

public class InitialisationVector {
    public static final int IV_LENGTH = 12;
    // Generate Initialisation Vector.
    public static IV generateIV()
    {
        long ivGenTimeStart = System.nanoTime();

        byte[] iv = new byte[IV_LENGTH];
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);

        long ivGenTimeEnd = System.nanoTime();
        double elapsedTime = (ivGenTimeEnd - ivGenTimeStart) / 1000000.0;
        System.out.println("IV generation time : " + elapsedTime + " ms.");

        return new IV(iv);
    }
}
