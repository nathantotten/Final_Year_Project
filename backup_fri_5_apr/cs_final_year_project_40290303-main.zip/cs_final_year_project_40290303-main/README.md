# CS_Final_Year_Project_40290303

## Overview of Repository
This repository contains the documentation, write-up, and any implementation/code for my final year Computer Science project.

The focus of this project is *Symmetric Searchable Encryption for Cloud Data* - with a focus on a search-friendly, efficient tool for searching through encrypted commercial data.

The project code is stored in the java project: cs_proj_40290303.

## Acknowledgements
I'd like to give a massive thanks to my supervisor, Dr Indranil Ghosh Ray, for his continued support, enthusiasm, and mentoring with this new and challenging area of study. 
As someone who is very new to the world of efficient implementations of cryptography and its application to the cloud, this guidance is invaluable.



